#include "geese.h"
#include "gamemanager.h"
#include <limits>

geese::geese(int currTile): currTile(currTile) {}

void geese::moveGeese(int newTile, Tile** tileArr) {
    tileArr[currTile]->updateGeese();
    tileArr[newTile]->updateGeese();
}

void geese::stealResource(GameManager* g) {
    std::vector<Player*> players = g->getPlayers();

    for (Player* player : players) {
        int totalResources = 0;
        vector<string> resourceNames = {"CAFFEINE", "LAB", "LECTURE", "STUDY", "TUTORIAL"};
        vector<int> resourceCounts;

        for (const string& resource : resourceNames) {
            int count = player->getResourceCount(resource);
            resourceCounts.push_back(count);
            totalResources += count;
        }

        if (totalResources >= 10) {
            int resourcesToLose = totalResources / 2; 
            cout << "Student " << player->getColor() << " loses " 
                << resourcesToLose << " resources to the geese. They lose:" << endl;

            vector<int> lostResources(resourceCounts.size(), 0); 
            vector<int> cumulativeProbabilities;
            int runningTotal = 0;

            
            for (int count : resourceCounts) {
                runningTotal += count;
                cumulativeProbabilities.push_back(runningTotal);
            }

            
            for (int i = 0; i < resourcesToLose; ++i) {
                int randomValue = rand() % totalResources + 1; 

                for (size_t j = 0; j < cumulativeProbabilities.size(); ++j) {
                    if (randomValue <= cumulativeProbabilities[j]) {
                        player->removeResources(resourceNames[j], 1);
                        lostResources[j]++; 
                        totalResources--; 
                        resourceCounts[j]--; 
                        break;
                    }
                }
            }


            for (size_t i = 0; i < lostResources.size(); ++i) {
                if (lostResources[i] > 0) {
                    cout << lostResources[i] << " " << resourceNames[i] << endl;
                }
            }
        }
    }


    cout << "Choose where to place the GEESE." << endl;
    int geeseTile;
    cin >> geeseTile;

    

    string currPlayer = g->getCurrentPlayer();

    Player* currentPlayer;

    for (int i = 0; i < 4; i++) {
        if (currPlayer == players[i]->getColor()) {
            currentPlayer = players[i];
            break;
        }
    }

    vector <string> playersOnTile;
    Tile* tile = g->getBoard()->getTile(geeseTile);
    Vertex** vertArr = tile->getAdjacentVertices();

    for (int i = 0; i < 6; i++) {
        if (!vertArr[i]->isAvailable()) {
            playersOnTile.push_back(vertArr[i]->getName());
        }
    }

    if (playersOnTile.empty()) {
        cout << "Student " << currPlayer << " has no students to steal from." << endl;
        return;
    }

    for (const string& p : playersOnTile) {
        cout << "Student " <<  currPlayer << " can choose to steal from " << p << "." << endl;
    }

    cout << "Choose a student to steal from." << endl;

    string targetPlayer;

    while (true) {
        cin >> targetPlayer;
        if (cin.fail()) {
            cin.clear(); 
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 
            cout << "Invalid input. Please enter a valid player." << endl;
            continue;
        }
        if (find(playersOnTile.begin(), playersOnTile.end(), targetPlayer) != playersOnTile.end()) {
            break;
        }

        cout << "Invalid choice. Please choose a valid student to steal from: ";
    }

    Player* target;

    for (int i = 0; i < 4; i++) {
        if (targetPlayer == players[i]->getColor()) {
            target = players[i];
            break;
        }
    }

    int totalResources = 0;
    vector<string> resourceNames = {"CAFFEINE", "LAB", "LECTURE", "STUDY", "TUTORIAL"};
    for (const string& resource : resourceNames) {
        totalResources += target->getResourceCount(resource);
    }

    if (totalResources == 0) {
        cout << "Student " << targetPlayer << " has no resources to steal." << endl;
        return;
    }

    vector<int> cumulativeProbabilities;
    int runningTotal = 0;
    for (const string& resource : resourceNames) {
        runningTotal += target->getResourceCount(resource);
        cumulativeProbabilities.push_back(runningTotal);
    }

    int randomValue = rand() % totalResources + 1;

    string stolenResource;
    for (size_t i = 0; i < cumulativeProbabilities.size(); ++i) {
        if (randomValue <= cumulativeProbabilities[i]) {
            stolenResource = resourceNames[i];
            break;
        }
    }

    target->removeResources(stolenResource, 1);
    currentPlayer->addResources(stolenResource, 1);

    cout << "Student " << currPlayer << " steals " << stolenResource << " from student " << targetPlayer << "." << endl;

    moveGeese(geeseTile, g->getBoard()->getTiles());
}

